package com.example.user.sayin.model;

import java.io.Serializable;

/**
 * Created by root on 8/8/17.
 */

public class TodayExpense implements Serializable {
    public String item_name,amount;
}
