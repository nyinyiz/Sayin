package com.example.user.sayin.events;

/**
 * Created by root on 8/8/17.
 */

public class InternalEvent {
    public static class TodayExpenseItemUpdate{

    }
}
